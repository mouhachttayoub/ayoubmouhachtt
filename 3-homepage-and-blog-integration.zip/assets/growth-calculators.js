(() => {
  'use strict';
  const validate = values => {
    if (Object.values(values).some(v => !Number.isFinite(v) || v < 0)) throw new Error('Enter a valid non-negative number in every field.');
  };
  const calculate = (type, v) => {
    validate(v);
    if (type === 'breakeven') {
      if (v.revenue <= 0) throw new Error('Revenue must be greater than zero.');
      const contribution = v.revenue - v.cost;
      if (contribution <= 0) throw new Error('The model has no positive contribution before advertising. Review price and variable costs.');
      const allowed = contribution - v.profit;
      if (allowed <= 0) throw new Error('The desired contribution leaves no positive advertising allowance.');
      return { contribution, margin: contribution / v.revenue, allowed, breakEven: v.revenue / contribution, target: v.revenue / allowed };
    }
    if (type === 'discount') {
      if (v.price <= 0 || v.orders <= 0 || !Number.isInteger(v.orders)) throw new Error('Price must be positive and baseline orders must be a positive whole number.');
      if (v.discount >= 100) throw new Error('The discount must be below 100%.');
      const original = v.price - v.cost;
      const discountedPrice = v.price * (1 - v.discount / 100);
      const discounted = discountedPrice - v.cost;
      if (original <= 0 || discounted <= 0) throw new Error('Both offers need positive contribution. More orders cannot repair zero or negative contribution per order in this model.');
      const required = Math.ceil((original * v.orders + v.extra) / discounted);
      return { original, discountedPrice, discounted, required, additional: required - v.orders, uplift: (required / v.orders - 1) * 100 };
    }
    if (type === 'marginal') {
      if (v.newSpend <= v.oldSpend) throw new Error('The higher spend must exceed the earlier spend.');
      if (v.margin > 100) throw new Error('Margin must be between 0% and 100%.');
      const spend = v.newSpend - v.oldSpend;
      const revenue = v.newRevenue - v.oldRevenue;
      return { spend, revenue, roas: revenue / spend, contribution: revenue * v.margin / 100 - spend };
    }
    throw new Error('Unknown worksheet.');
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = { calculate };
  if (typeof document === 'undefined') return;
  const format = n => new Intl.NumberFormat('en', { maximumFractionDigits: 2 }).format(n);
  document.querySelectorAll('[data-growth-calculator]').forEach(form => {
    const output = form.querySelector('[data-result]');
    form.addEventListener('submit', event => {
      event.preventDefault();
      try {
        const values = {};
        form.querySelectorAll('input').forEach(input => {
          if (input.value.trim() === '') throw new Error('Complete every field.');
          values[input.name] = Number(input.value);
        });
        const type = form.dataset.growthCalculator;
        const r = calculate(type, values);
        let result;
        if (type === 'breakeven') result = `Contribution before ads: ${format(r.contribution)} (${format(r.margin * 100)}%).\nAllowable ad cost per order: ${format(r.allowed)}.\nBreak-even ROAS before the desired contribution: ${format(r.breakEven)}.\nROAS required for your contribution goal: ${format(r.target)}.`;
        else if (type === 'discount') result = `Discounted price: ${format(r.discountedPrice)}.\nContribution per discounted order: ${format(r.discounted)}.\nWhole orders required: ${format(r.required)}.\nAdditional orders: ${format(r.additional)} (${format(r.uplift)}% above baseline).`;
        else result = `Additional spend: ${format(r.spend)}.\nObserved revenue change: ${format(r.revenue)}.\nObserved marginal ROAS: ${format(r.roas)}.\nChange in contribution after extra spend: ${format(r.contribution)}.`;
        output.textContent = result.replace(/\\n/g, '\n');
        output.dataset.error = 'false';
      } catch (error) {
        output.textContent = error.message;
        output.dataset.error = 'true';
      }
    });
  });
})();
